﻿using System;
using System.Linq;

namespace EntityWorkshop
{
    class Program
    {
        static void Main(string[] args)
        {
            DBFirstDemoContext context = new DBFirstDemoContext(); //Instantie van context aanmaken

            //Neighbourhood aanmaken
            var newNeighbourhood = new Neighbourhoods()
            {
                Neighbourhood = "NewNeighbourhood"
            };
            context.Neighbourhoods.Add(newNeighbourhood); //Neighbourhood toevoegen
            context.SaveChanges(); //Wijzigingen opslaan

            var foundNeighbourhood = context.Neighbourhoods.Find(newNeighbourhood.NeighbourhoodId); //Neighbourhood vinden met primary key

            Console.WriteLine("Neighbourhood found: " + foundNeighbourhood.Neighbourhood);

            var foundNeighbourhoods = context.Neighbourhoods.Where(n => n.Neighbourhood.ToLower().Contains("a")); //Alle Neighbourhoods vinden met de letter a

            foundNeighbourhood.Neighbourhood = "UpdatedNeighbourhood"; //Properties aanpassen

            context.SaveChanges(); //Wijzigingen opslaan

            context.Neighbourhoods.Remove(foundNeighbourhood); //Bestaande Neighbourhood verwijderen

            context.Neighbourhoods.RemoveRange(foundNeighbourhoods); //Meerdere Neighbourhoods verwijderen

            context.SaveChanges(); //Wijzigingen opslaan

        }
    }
}
