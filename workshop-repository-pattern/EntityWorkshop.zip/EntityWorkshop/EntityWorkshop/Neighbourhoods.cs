﻿using System;
using System.Collections.Generic;

namespace EntityWorkshop
{
    public partial class Neighbourhoods
    {
        public string NeighbourhoodGroup { get; set; }
        public string Neighbourhood { get; set; }
        public int NeighbourhoodId { get; set; }
    }
}
