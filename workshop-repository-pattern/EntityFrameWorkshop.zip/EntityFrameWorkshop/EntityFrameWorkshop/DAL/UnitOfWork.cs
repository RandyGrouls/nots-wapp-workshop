﻿using EntityFrameWorkshop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameWorkshop.DAL
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DBFirstDemoContext context;
        public INeighbourhoodsRepository Neighbourhoods { get; private set; }
        //Voeg hier extra repositories toe

        public UnitOfWork(DBFirstDemoContext context)
        {
            this.context = context;
            Neighbourhoods = new NeighbourhoodsRepository(context);
        }

        public int Complete()
        {
            return context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }
    }
}
