﻿using EntityFrameWorkshop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameWorkshop.DAL
{
    public class NeighbourhoodsRepository : Repository<Neighbourhoods>, INeighbourhoodsRepository
    {
        public DBFirstDemoContext DemoContext
        {
            get { return context as DBFirstDemoContext; }
        }

        public NeighbourhoodsRepository(DBFirstDemoContext context) : base(context)
        {
        }

        public IEnumerable<Neighbourhoods> GetNeighbourhoodsContainingString(string indexString)
        {
            return DemoContext.Neighbourhoods.Where(n => n.Neighbourhood.ToLower().Contains(indexString));
        }
    }
}
