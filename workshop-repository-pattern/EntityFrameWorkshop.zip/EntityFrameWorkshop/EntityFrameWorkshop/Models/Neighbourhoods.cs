﻿using System;
using System.Collections.Generic;

namespace EntityFrameWorkshop.Models
{
    public partial class Neighbourhoods
    {
        public string NeighbourhoodGroup { get; set; }
        public string Neighbourhood { get; set; }
        public int NeighbourhoodId { get; set; }
    }
}
