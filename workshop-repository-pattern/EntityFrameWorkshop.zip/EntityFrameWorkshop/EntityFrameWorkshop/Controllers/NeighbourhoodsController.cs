﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EntityFrameWorkshop.Models;
using EntityFrameWorkshop.DAL;

namespace EntityFrameWorkshop.Controllers
{
    public class NeighbourhoodsController : Controller
    {
        private UnitOfWork unitOfWork;

        public NeighbourhoodsController(DBFirstDemoContext context)
        {
            unitOfWork = new UnitOfWork(context);
        }

        // GET: Neighbourhoods
        public IActionResult Index()
        {
            return View(unitOfWork.Neighbourhoods.GetAll());
        }

        // GET: Neighbourhoods/Details/5
        public async Task<IActionResult> Details(int id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            var neighbourhoods = unitOfWork.Neighbourhoods.Get(id);
            if (neighbourhoods == null)
            {
                return NotFound();
            }

            return View(neighbourhoods);
        }

        // GET: Neighbourhoods/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Neighbourhoods/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NeighbourhoodGroup,Neighbourhood,NeighbourhoodId")] Neighbourhoods neighbourhoods)
        {
            if (ModelState.IsValid)
            {
                unitOfWork.Neighbourhoods.Add(neighbourhoods);
                unitOfWork.Complete();
                return RedirectToAction(nameof(Index));
            }
            return View(neighbourhoods);
        }

        // GET: Neighbourhoods/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            var neighbourhoods = unitOfWork.Neighbourhoods.Get(id);
            if (neighbourhoods == null)
            {
                return NotFound();
            }
            return View(neighbourhoods);
        }

        // POST: Neighbourhoods/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NeighbourhoodGroup,Neighbourhood,NeighbourhoodId")] Neighbourhoods neighbourhoods)
        {
            if (id != neighbourhoods.NeighbourhoodId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var found = unitOfWork.Neighbourhoods.Get(id);

                    found.Neighbourhood = neighbourhoods.Neighbourhood;
                    found.NeighbourhoodGroup = neighbourhoods.NeighbourhoodGroup;

                    unitOfWork.Complete();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NeighbourhoodsExists(neighbourhoods.NeighbourhoodId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(neighbourhoods);
        }

        // GET: Neighbourhoods/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            var neighbourhoods = unitOfWork.Neighbourhoods.Get(id);
            if (neighbourhoods == null)
            {
                return NotFound();
            }

            return View(neighbourhoods);
        }

        // POST: Neighbourhoods/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var neighbourhoods = unitOfWork.Neighbourhoods.Get(id);
            unitOfWork.Neighbourhoods.Remove(neighbourhoods);
            unitOfWork.Complete();
            return RedirectToAction(nameof(Index));
        }

        private bool NeighbourhoodsExists(int id)
        {
            return unitOfWork.Neighbourhoods.Get(id) != null;
        }
    }
}
